<?php
/**
 * Plugin Name: Edfapay Payment Gateway
 * Plugin URI: https://edfapay.com
 * Description: Accept payments on your WooCommerce site in a seamless and secure checkout environment.
 * Version: 5.3.1
 * Author: Edfapay
 * Author URI: https://Edfapay.com/
 * License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: woocommerce-web-payment-gateway
 *
 * @package WordPress
 * @author Edfapay
 * @since 1.0.0
 */



/**
 * WPG Main Commerce Class
 */
class WC_WPG {


	/**
	 * Constructor
	 */
	public function __construct() {
		define( 'WC_WPG_VERSION', '5.3.1' );
		define( 'WC_WPG_TEMPLATE_PATH', untrailingslashit( plugin_dir_path( __FILE__ ) ) . '/templates/' );
		define( 'WC_WPG_PLUGIN_URL', untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) ) );
		define( 'WC_WPG_PLUGIN_DIR', plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) . '/' );
		define( 'WC_WPG_MAIN_FILE', __FILE__ );

		// Actions
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'plugin_action_links' ) );
		add_action( 'plugins_loaded', array( $this, 'init' ), 0 );
		add_filter( 'woocommerce_payment_gateways', array( $this, 'register_gateway' ) );
	
		
		//check payment transaction
		add_action('wp_head', array($this, 'style_check_transaction_loader_css'),999);
		add_action('wp_footer', array($this, 'script_check_transaction_status_by_ajax'),999);
		add_action('wp_ajax_nopriv_get_transaction_id_sss', array($this, 'get_transaction_id_sss_callback'));
		add_action('wp_ajax_get_transaction_id_sss', array($this, 'get_transaction_id_sss_callback'));
		add_action('woocommerce_before_thankyou', array($this, 'sss_check_transaction_loader'), 10, 1);
		// gutenberg/block woocommerce checkout compatibility
		// Hook the custom function to the 'before_woocommerce_init' action
		add_action('before_woocommerce_init', array($this, 'declare_cart_checkout_blocks_compatibility'));
        add_action('woocommerce_api_edfapay_process', array($this, 'edfapay_callback'));

		// Hook the custom function to the 'woocommerce_blocks_loaded' action
		add_action( 'woocommerce_blocks_loaded', array($this, 'edfapy_register_order_approval_payment_method_type') );
	}

	/**
	 * Add info and links to plugin in options
	 * @param  array $links
	 * @return array
	 */
	public function plugin_action_links( $links ) {
		$subscriptions = ( class_exists( 'WC_Subscriptions_Order' ) ) ? '_subscriptions' : '';
		if ( class_exists( 'WC_Subscriptions_Order' ) && ! function_exists( 'wcs_create_renewal_order' ) ) {
			$subscriptions = '_subscriptions_deprecated';
		}
		$plugin_links = array(
			'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=wpgfull' . $subscriptions ) . '">' . __( 'Settings', 'woocommerce-web-payment-gateway' ) . '</a>',

		);
		return array_merge( $plugin_links, $links );
	}

	/**
	 * localisations and files
	 */
	public function init() {

		if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
			return;
		}

		// Includes
		include_once( 'includes/class-wc-web-payment-gateway.php' );

		if ( class_exists( 'WC_Subscriptions_Order' ) ) {
			//include_once( 'includes/class-wc-web-payment-gateway-subscriptions.php' );
		}

		// Localisation
		load_plugin_textdomain( 'woocommerce-web-payment-gateway', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	}

	/**
	 * Select the gateway for use
	 */
	public function register_gateway($methods)
	{

		if (
			class_exists('WC_Subscriptions_Order')
		) {
			//$methods[] = 'WC_Web_Payment_Gateway_Subscriptions';
		} else {

			$methods[] = 'WC_Web_Payment_Gateway';
		}

		return $methods;
	}
	/**
	 * Custom function to declare compatibility with cart_checkout_blocks feature 
	*/
	public function declare_cart_checkout_blocks_compatibility() {
		// Check if the required class exists
		if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
			// Declare compatibility for 'cart_checkout_blocks'
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
		}
	}


	/**
	 * Custom function to register a payment method type

	 */
	public function edfapy_register_order_approval_payment_method_type() {
		// Check if the required class exists
		if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
			return;
		}

		// Include the custom Blocks Checkout class
		require_once plugin_dir_path(__FILE__) . '/includes/class-edfapay-block.php';

		// Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
		add_action(
			'woocommerce_blocks_payment_method_type_registration',
			function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
				// Register an instance of My_Custom_Gateway_Blocks
				$payment_method_registry->register( new Edfapay_payment_Blocks );
			}
		);
	}
	public function script_check_transaction_status_by_ajax(){
		if ( is_wc_endpoint_url( 'order-received' ) && isset($_GET['key']) && !empty($_GET['key'])) {
			$order_key = $_GET['key'];
			$order_id = wc_get_order_id_by_order_key( $order_key );
			$order = wc_get_order( $order_id );
			//added by adnan.hashmi on Apr 17, 2024
			if ($order->get_payment_method()!=="wpgfull"){
				return;
			}
			//End of added code by adnan.hashmi
			$transaction_id = $order->get_transaction_id();
			//if( empty($transaction_id) ):
			?>
			<script>
				var order_id = <?= $order_id ?>;
				jQuery(document).ready(function($){
					setTimeout(check_transaction_id_and_status, 5000);
					function check_transaction_id_and_status(){
						jQuery.ajax({
							url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
							type: 'post',
							dataType: "json",
							data: { 
								action: 'get_transaction_id_sss',
								id: order_id
							},
							success: function(data) {
								console.log('check data array after order placed and API response back', data);
								// normal woocommerce checkout page
								if($('.woocommerce-thankyou-order-received').length >0 ){
								if(data==0){
// 									setTimeout(check_transaction_id_and_status, 3000);
									$('.woocommerce-thankyou-order-received').text('Sorry, your payment failed. Your order is now in Pending Mode.');
								}else if(data[1]=='pending'){
									$('.woocommerce-thankyou-order-received').text('Sorry, your payment failed. Your order is now in Pending Mode.');
								}else if(data[1]=='processing'){
									$('.woocommerce-thankyou-order-received').text('Thank you for your successful payment! Your order is processing now.');
								}else if(data[1]=='completed'){
									$('.woocommerce-thankyou-order-received').text('Thank you for your successful payment! Your order is completed now.');
								}else{
									$('.woocommerce-thankyou-order-received').text('Sorry, your payment failed. Your order is now in Pending Mode.');
								}
								} // end normal woocoommerce checkout page
								// new block woocommerce checkout page
								if($('.wc-block-order-confirmation-status').length >0 ){
									if(data==0){
	// 									setTimeout(check_transaction_id_and_status, 3000);
										$('.wc-block-order-confirmation-status p').text('Sorry, your payment failed. Your order is now in Pending Mode.');
									}else if(data[1]=='pending'){
										$('.wc-block-order-confirmation-status p').text('Sorry, your payment failed. Your order is now in Pending Mode.');
									}else if(data[1]=='processing'){
										$('.wc-block-order-confirmation-status p').text('Thank you for your successful payment! Your order is processing now.');
									}else if(data[1]=='completed'){
										$('.wc-block-order-confirmation-status p').text('Thank you for your successful payment! Your order is completed now.');
									}else{
										$('.wc-block-order-confirmation-status p').text('Sorry, your payment failed. Your order is now in Pending Mode.');
									}
								}
								$('.sss_main_loader').hide();
							}
						});
					}
				});
			</script>
			<?php
			//endif;
		}
	}

	public function get_transaction_id_sss_callback(){
		if( isset($_POST['id']) && !empty($_POST['id']) && isset($_POST['action']) && $_POST['action']=='get_transaction_id_sss' ){
			$order_id = $_POST['id'];
			$order = wc_get_order( $order_id );
			$transaction_id = $order->get_transaction_id();
			$payment_status = $order->get_status();
			if(!empty($transaction_id)){
				echo json_encode(array($transaction_id,$payment_status));
			}else{
				echo json_encode(0);
			}
		}
		die();
	}
	
	public function style_check_transaction_loader_css(){
		if( is_wc_endpoint_url( 'order-received' ) ):
		?>
		<style>
			.sss_main_loader{
				position: fixed;
				left: 0;
				top: 0;
				width: 100%;
				height: 100%;
				background: white;
			}
			.sss_inner_loader{
				width: 100%;
				height: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
			}
			.sss_inner_loader img{
				width:500px;
			}
		</style>
		<?php
		endif;
	}

	public function sss_check_transaction_loader($order_id){
		$order = wc_get_order( $order_id );
		//added by adnan.hashmi on Apr 17, 2024
		if ($order->get_payment_method()!=="wpgfull"){
			return;
		}
		//End of added code by adnan.hashmi
		
		$transaction_id =  $order->get_transaction_id();
// 		$payment_status = get_post_meta($order_id,'_edfapay_payment_status',true);
		if( empty($transaction_id) ): ?>
			<div class="sss_main_loader">
				<div class="sss_inner_loader">
					<img src="<?= WC_WPG_PLUGIN_DIR.'images/EdfaLoading.gif' ?>">
				</div>
			</div>
		<?php
		endif;
	}
	public function edfapay_callback(){
		sleep(5);
		$orderId   = base64_decode($_GET['orderId']);
		$order         = new WC_Order($orderId); //todo switch to wc_get_order
		
		wp_redirect( $order->get_checkout_order_received_url() );
		exit;
	}

}


new WC_WPG();
