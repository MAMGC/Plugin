<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Edfapay_payment_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'wpgfull';// your payment gateway name

    public function initialize() {
        $this->settings = get_option( 'woocommerce_wpgfull_enabled');
        // you can also initialize your payment gateway here
		 $gateways = WC()->payment_gateways->payment_gateways();
		 $this->gateway  = $gateways[ $this->name ];
        // print_r($this->gateway->enabled);
    }

    public function is_active() {
        return ! empty( $this->gateway->enabled ) && 'yes' === $this->gateway->enabled;
    }
    public function get_payment_method_script_handles() {

        wp_register_script(
            'custom-edfapay-blocks-integration',
            plugin_dir_url(__DIR__) . 'js/edfapay-block-checkout.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            '1.0',
            true
        );
        // if( function_exists( 'wp_set_script_translations' ) ) {
        //     wp_set_script_translations( 'edfapay-blocks-integration');
            
        // }
        return [ 'custom-edfapay-blocks-integration' ];
    }

    public function get_payment_method_data() {
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
        ];
    }

}

?>