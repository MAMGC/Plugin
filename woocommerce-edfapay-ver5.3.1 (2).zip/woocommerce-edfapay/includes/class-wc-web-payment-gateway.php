<?php


if (!defined('ABSPATH')) {
	exit;
}

/**
 * WC_Web_Payment_Gateway class.
 *
 * @since 2.0.0
 * @extends WC_Payment_Gateway
 */
class WC_Web_Payment_Gateway extends WC_Payment_Gateway
{

	private $apimethod = array(
		'checkout' => '/payment/initiate',
		'refund'   => '/payment/refund'
	);

	public $debug = 'no';


	public $currencies_3dotexponent = ['BHD', 'JOD', 'KWD', 'OMR', 'TND'];
	public $currencies_noexponent = [
		//'CLP', 
		'VND', 
		'ISK', 
		'UGX', 
		//'KRW', 
		//'JPY'
	];

	/**
     * Constructor
     */
	public function __construct()
	{
		global $woocommerce;
		// Register plugin information
		$this->id = 'wpgfull';
		$this->has_fields = true;
		$this->url = $this->get_option( 'edfa_api_url' );
		$this->secret = $this->get_option( 'secret' );
		$this->password = $this->get_option( 'password' );
		$this->debug = $this->get_option( 'debug' );
		$this->supports = array(
			'refunds',
			'products',
			//'subscriptions',
			//'subscription_cancellation',
			//'subscription_suspension',
			//'subscription_reactivation',
			//'subscription_amount_changes',
			//'subscription_date_changes',
			//'subscription_payment_method_change',
			//'subscription_payment_method_change_customer',
			//'subscription_payment_method_change_admin',
		);

		// Create plugin fields and settings
		$this->init_form_fields();
		$this->init_settings();

		// Get setting values
		foreach ($this->settings as $key => $val) {
			$this->$key = $val;
		}



		if (empty($this->icon)) {
			// Load plugin checkout default icon
			$this->icon = WC_WPG_PLUGIN_URL . '/images/default-logo.png" alt="Icon" style="max-height: 48px!important;max-width:250px';
		}


		if ($this->display_icon == 'yes') {
			$this->icon = false;
		}

		//image select
		add_action('admin_enqueue_scripts', array($this, 'loadscripts'));
		add_action('woocommerce_api_wc_set_picture', array($this, 'get_new_image'));


		// Add hooks
		add_action('woocommerce_receipt_'.$this->id, array($this, 'receipt_page'));
		//add_action('woocommerce_update_options_payment_gateways', array($this, 'process_admin_options'));
		add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

		add_action('admin_notices', array($this, 'wpgfull_commerce_ssl_check'));

		// Payment listener/API hook
		//add_action('woocommerce_api_wpgfull_webhook', array($this, 'check_ipn_response')); // code by noumam and 100% working 
		// add old webhook for notification (Nouman)
		add_action('woocommerce_api_wc_web_payment_gateway', array($this, 'check_ipn_response'));

		// add_filter('woocommerce_thankyou_order_received_text', array($this, 'custom_ty_msg'), 10, 2); // not used 


	}

	// public function custom_ty_msg($thankyou_text,$order) 
	// {
	// 	//Updated by adnan.hashmi on Apr 22, 2024
	// 	if($order->get_payment_method()!=="wpgfull"){
	// 		return $thankyou_text;
	// 	}
	// 	//end of updated code by adnan.hashmi
	// 	$counter = 0;
	// 	$payment_status = $order->get_status(); 
	// 	while ($payment_status == 'pending' && $counter < 5) {
	// 		$counter = $counter + 1;
	// 		sleep(2);
	// 		if ('yes' == $this->debug) {
	// 			$log = new WC_Logger();
	// 			$log->add('wpgLog', 'isset($order)' . ' - '. isset($order) . '--- ');
	// 		} 
	// 	}



	// 	$transaction_id = $order->get_transaction_id();
	// 	$ordId = $order->get_id();


	// 	if ('yes' == $this->debug) {
	// 		$log = new WC_Logger();
	// 		$log->add('wpgLog', '#1 payment_status: ' . $payment_status . 'transaction id: ' . $transaction_id . ' orderid: '. $ordId);
	// 	} 
	// 	if ($payment_status == 'processing' || $payment_status == 'completed') {
	// 		// Customize the thank-you message for successful payments
	// 		$thankyou_text = 'Thank you for your successful payment! Your order is processing now.';
	// 	} else {
	// 		// Customize the thank-you message for failed payments
	// 		$thankyou_text = 'Sorry, your payment failed. Your order is now in Pending Mode.';
	// 	}

	// 	return $thankyou_text;
	// }



	public function get_new_image()
	{
		if (isset($_GET['id'])) {
			$data = array(
				'image'    => wp_get_attachment_image(filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT), array(90, 20), false, array('id' => 'wpg_custom_logo_prewiev')),
				'imageurl' => wp_get_attachment_image_url(filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT), array(90, 20), true),
			);
			wp_send_json_success($data);
		} else {
			wp_send_json_error();
		}
	}

	function loadscripts($page)
	{
		if ($page == 'woocommerce_page_wc-settings') {
			wp_enqueue_media();
			wp_enqueue_script('wpg_load_logo', WC_WPG_PLUGIN_DIR . 'js/wpg_load_logo.js', array('jquery'));
		}
	}


	/**
     * Refund function for gateway if suppors
     **/

	public function process_refund($order_id, $amount = null, $reason = '')
	{
		$order = wc_get_order($order_id);
		if (!is_a($order, \WC_Order::class)) {
			return false;
		}

		$correct_amount = number_format($amount, 2, '.', '');
		if (in_array(get_woocommerce_currency(), $this->currencies_noexponent)) {
			$correct_amount = number_format($order->get_total(), 0, '.', '');
		}elseif (in_array(get_woocommerce_currency(), $this->currencies_3dotexponent)) {
			$correct_amount = number_format($order->get_total(), 3, '.', '');
		}


		//updated by adnan.hashmi as it was not picking the url Nov 18, 2024
		$this->url = $this->get_option('edfa_api_url');
		//end of updated code

		$transaction_id = $order->get_transaction_id();
		$hash = sha1(md5(strtoupper($transaction_id . $correct_amount . $this->password)));
		$action_adr = rtrim($this->url,'/').$this->apimethod['refund'];

		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => $action_adr,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS =>'{
			"gwayId": "'.$transaction_id.'",
			"order_id": "'.$order_id.'",
			"edfa_merchant_id": "'.$this->secret.'",
			"hash": "'.$hash.'",
			"payer_ip": "176.44.76.222",
			"amount":"'.$correct_amount.'"
		}',
			CURLOPT_HTTPHEADER => array(
				'Content-Type: application/json'
			),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		//echo $response;
		$response = json_decode($response, true);
		if ($response['responseBody']['result'] == 'accepted' && $response['responseBody']['payment_id'] == $transaction_id) {
			return true;
		}

		return false;
	}

	//added by adnan.hashmi on Sep 04, 2023
	function reverseString($str) {
		return strrev($str);
	}
	//end of code by adnan.hashmi
	//Notificaiton 
	function check_ipn_response()
	{
		global $woocommerce;
// 		if ('yes' == $this->debug) {
// 			$log = new WC_Logger();
// 			foreach ($_POST as $key => $value) {
// 				// Print the key and value
// 				//below line giving error some times CRITICAL Uncaught TypeError: htmlspecialchars(): Argument #1 ($string) must be of type string
// 				$log->add('wpgLog', htmlspecialchars($key) . ': --- ' . htmlspecialchars($value));
// 			}
// 		}
// $_POST = $_GET;
				// print_r($_POST); die;

		$order_id = NULL;
		//Added code by adnan.hashmi on Sep 06, 2023 -- Check weather notificaiton is becaues of Apple pay or simple s2s response
		$isFromApplePay = false;
		$isTamara = false;
		if (isset($_POST['source']) && $_POST['source'] == 'tamara'){
			if ('yes' == $this->debug) {
				$log = new WC_Logger();
				$log->add('wpgLog', 'Notification Tamara - order_number:' . $_POST['order_number']);
			}
			$order_id = $_POST['order_number']; //tamara

			$isTamara = true;
		} else if (!empty($_POST['card']) && !empty($_POST['card_expiration_date'])) {
			$order_id = $_POST['order_id'];
		} else {
			//Meaning it is from Apple pay or hosted checkout
			$isFromApplePay = true;
			$order_id = $_POST['order_id'];
		}
		// echo $order_id; die;
		//saving response of transaction
// 		if(isset($_POST['status']) && !empty($_POST['status'])){
// 			update_post_meta($order_id,'_edfapay_payment_status',$_POST['status']);
// 		}
		
		$order = new WC_Order($order_id);

		if (is_null($order)) {
			if ('yes' == $this->debug) {
				$log = new WC_Logger();
				$log->add('wpgLog', 'order is null');
			}
			exit;
		} 

		if ('yes' == $this->debug) {
			$log = new WC_Logger();
			$log->add('wpgLog', '$order_id: ' . $order_id);
		}

		$hash = NULL;
		if ( $isFromApplePay ) {
			// Must be SHA1 of MD5 encoded string (uppercased): payment_public_id + order.number + order.amount + order.currency + order.description + merchant.pass
			// $concatinated_string = $_POST['id'] . $_POST['order_number'] . $_POST['order_amount'] . $_POST['order_currency'] . $_POST['order_description'] . $this->password; 
			// $hash = sha1(md5(strtoupper($concatinated_string)));
			$hash = null;;
		} else if ( $isTamara ) {
			if ('yes' == $this->debug) {
				$log = new WC_Logger();
				$log->add('wpgLog', ' T A M A R A  R E Q U E S T : ' . $order_id . ' ' . $_POST['id'] . ' ' . $_POST['status']);
			}
			//Tamara
		} else {
			//md5(strtoupper(strrev(email).PASSWORD.trans_id.strrev(substr(card_number,0,6).substr(card_number,-4))))
			$final = strtoupper(strrev($order->get_billing_email()) . $this->password . $_POST['trans_id'] .strrev(substr($_POST['card'], 0, 6) . substr($_POST['card'], -4)));
			$hash = md5($final);
		}


		// if ('yes' == $this->debug) {
		//     $log = new WC_Logger();
		//     $log->add('wpgLog', 'Generated Hash is : '  . $hash . ' and hash from request is : '. $_POST['hash']);
		// }

		if ($_POST['hash'] != $hash && !$isTamara  && !$isFromApplePay) {

			//error_log("hash invalid");
			if ('yes' == $this->debug) {
				$log = new WC_Logger();
				$log->add('wpgLog', 'hash does not match');
			}
			exit;
		}

		if ( $isFromApplePay ) {
			$order->set_transaction_id($_POST['trans_id']);
		} else if ( $isTamara ) {
			$order->set_transaction_id($_POST['id']);
		} else {
			$order->set_transaction_id($_POST['trans_id']);
		}

		if ('yes' == $this->debug) {
			$log = new WC_Logger();
			$log->add('wpgLog', 'transation_id : ' . $order->get_transaction_id());
		}
		if ($order->get_status() == 'pending' || $order->get_status() == 'cancelled'|| $order->get_status() == 'waiting' || $order->get_status() == 'failed' || $order->get_status() == '') {
			if ( $isFromApplePay ) {
				// if ('yes' == $this->debug) {
				//     $log = new WC_Logger();
				//     $log->add('wpgLog', 'inside isFromApplePay');
				// }
				if ($_POST['status'] == 'SETTLED' && $_POST['result'] == 'SUCCESS'&& $_POST['action'] == 'SALE') {
					$woocommerce->cart->empty_cart();
					//TODO change it back adnan.hashmi Jan 20, 2024
					$order->add_order_note( 'Payment successfully paid' );
					$order->payment_complete( $order_id );
					// $order->update_status('completed', 'Payment successfully paid');
					// end of code to make the order status as completed once payment done adnan.hashmi
					if ('yes' == $this->debug) {
						$log = new WC_Logger();
						$log->add('wpgLog', 'Order status should be updated to processing');
					}
					exit;
				}
				if ($_POST['status'] == 'DECLINED' && $_POST['action'] == 'SALE'){
					$order->update_status('failed', $_POST['decline_reason']);
					exit;
				}
			} else if ( $isTamara ) {
				if ($_POST['status'] == 'success' ) {
					$woocommerce->cart->empty_cart();
					//TODO change it back adnan.hashmi Jan 20, 2024
					$order->add_order_note( 'Payment successfully paid' );
					$order->payment_complete( $order_id );
					//$order->update_status('completed', 'Payment successfully paid');
					// end of code to make the order status as completed once payment done adnan.hashmi
					if ('yes' == $this->debug) {
						$log = new WC_Logger();
						$payment_status = $order->get_status(); 
						$log->add('wpgLog', 'Tamara payment status has been changed to ' . $payment_status);
					}
					exit;
				}
			} else {
				// echo "<pre>";
				// print_r($_POST); die;
				// if ($_POST['status'] == 'success' && $_POST['type'] == 'sale') {
				if ($_POST['status'] == 'SETTLED' && ($_POST['action'] == 'SALE')) {

					//successful purchase
					$woocommerce->cart->empty_cart();
					//updated by adnan.hashmi on Feb 09, 2023 to resolve the issue of complete if payment is done
					//TODO change it back adnan.hashmi Jan 20, 2024
					$order->add_order_note( 'Payment successfully paid' );
					$order->payment_complete( $order_id );
					// $order->update_status('processing', 'Payment successfully paid');
					// $order->update_status('completed', 'Payment successfully paid');
					// end of code to make the order status as completed once payment done adnan.hashmi

					//end of updated code by adnan.hashmi

					//$order->payment_complete($_POST['id']);
					exit;
				}

				if ($_POST['status'] == 'waiting' && $_POST['type'] == 'SALE') { //tocheck what should be for waiting adnan.hashmi Sep 04, 2023
					//waiting purchase
					//error_log('status fail sale');
					$order->update_status('on-hold', __('On hold', 'woocommerce'));
					exit;
				}
				
				// condition Updated by Nermeen Shoman //
				if ($_POST['status'] == 'DECLINED' && $_POST['action'] == 'SALE') { //todo check what should be against fail adnan.hashmi Sep 04, 2023
					//error_log('status fail sale');
					// $order->update_status('failed',  $_POST['reason']);
					// Updated by Nermeen Shoman //
					$order->update_status('failed',  $_POST['decline_reason']);

					exit;
				}
			}
			
		}

		//TODO implement the refund properly
		//TODO check and implentn refund adnan.hashmi Sep 04, 2023
		if ($order->get_status() == 'completed' || $order->get_status() == 'processing') {
			if ($_POST['status'] == 'success' && $_POST['type'] == 'refund') {
				//$order->update_status('refunded', __('Refunded', 'woocommerce'));
				$order->add_order_note('Refund confirmed by the payment system');
				exit;
			}
			if ($_POST['status'] == 'fail' && $_POST['type'] == 'refund') {
				$order->update_status('failed', $_POST['reason']);
				exit;
			}
		}
		if ('yes' == $this->debug) {
						$log = new WC_Logger();
						$payment_status = $order->get_status(); 
						$log->add('wpgLog', 'check $_POST Details ' . $_POST);
					}
	}


	/**
     * Check if SSL is enabled and notify the user.
     */
	function wpgfull_commerce_ssl_check()
	{
		//if (!$_POST)
		//if ('no' == get_option('woocommerce_force_ssl_checkout') && 'yes' == $this->enabled) {
		if (is_ssl() == false && 'yes' == $this->enabled) {
			$admin_url = admin_url('admin.php?page=wc-settings&tab=checkout');
			echo '<div class="notice notice-error is-dismissible"><p>' . sprintf(__('WPG is enabled. But <a href="%s">force SSL option</a> is disabled. Your checkout is not secure! Please enable SSL and ensure your server has a valid SSL certificate.', 'woocommerce-gateway-wpgfull'), $admin_url) . '</p></div>';
		}
	}

	/**
     * Initialize Gateway Settings Form Fields.
     */
	function init_form_fields()
	{

		$this->form_fields = array(
			'enabled' => array(
				'title' => __('Enable/Disable', 'woocommerce-gateway-wpgfull'),
				'label' => __('Enable WPG Commerce', 'woocommerce-gateway-wpgfull'),
				'type' => 'checkbox',
				'description' => '',
				'default' => 'no',
			),
			'title' => array(
				'title' => __('Title', 'woocommerce-gateway-wpgfull'),
				'type' => 'text',
				'description' => __('This controls the title which the user sees during checkout.', 'woocommerce-gateway-wpgfull'),
				'default' => __('WPG Commerce', 'woocommerce-gateway-wpgfull'),
				'desc_tip' => true,
			),
			'description' => array(
				'title' => __('Front description', 'woocommerce-gateway-wpgfull'),
				'type' => 'text',
				'default' => __('Pay online through WPG Commerce', 'woocommerce-gateway-wpgfull'),
			),
			'method_description' => array(
				'title' => __('Description', 'woocommerce-gateway-wpgfull'),
				'type' => 'textarea',
				'description' => __('WPG redirects customers enter payment details.', 'woocommerce-gateway-wpgfull'),
				'default' => __('You can make a payment through the Web Payment Gateway system', 'woocommerce'),
			),
			'edfa_api_url' => array(
				'title' => __('Checkout host', 'woocommerce-gateway-wpgfull'),
				'type' => 'text',
				'description' => __('Url from payment system to send a payment request', 'woocommerce-gateway-wpgfull'),
			),
			// 'refundurl' => array(
			//     'title' => __('Refund Link', 'woocommerce-gateway-wpgfull'),
			//     'type' => 'text',
			//     'description' => __('Url from payment system to send a refund request', 'woocommerce-gateway-wpgfull'),
			// ),
			//Removed by adnan.hashmi on Jul 16, 2023
			// 'method' => array(
			//     'title' => __('Payment method', 'woocommerce-gateway-wpgfull'),
			//     'type' => 'multiselect',
			//     'description' => __('Payment method that client uses', 'woocommerce-gateway-wpgfull'), /////
			//     'options' => array(
			//         'card' => 'Card',
			//         'googlepay' => 'Google Pay',
			//         'playpal' => 'Pay Pal',
			//     ),
			// ),
			// End of commented code by adnan.hashmi
			'secret' => array(
				'title' => __('Merchant key', 'woocommerce-gateway-wpgfull'),
				'type' => 'text',
				'description' => __('Merchant key from payment system for customer identification', 'woocommerce-gateway-wpgfull'),
			),
			'password' => array(
				'title' => __('Merchant password', 'woocommerce-gateway-wpgfull'),
				'type' => 'text',
				'description' => __('Merchant password from payment system.', 'woocommerce-gateway-wpgfull'),
			),
			'debug' => array(
				'title' => __('Enable debug', 'woocommerce-gateway-wpgfull'),
				'type' => 'text',
				'default' => 'no',
				'description' => __('Enable debug logs', 'woocommerce-gateway-wpgfull'),
			),
			'display_icon' => array(
				'title' => __('Hide icon on front', 'woocommerce-gateway-wpgfull'),
				'type' => 'checkbox'
			),
			'icon' => array(
				//   'title' => __('Logo Url', 'woocommerce-gateway-wpgfull'),
				'type' => 'hidden',
				//  'description' => __('Logo that is displayed to customers', 'woocommerce-gateway-wpgfull'),
				'class' => 'wpg_custom_logo',
			),
		);
	}


	/**
     * UI - Admin Panel Options
     */





	function admin_options()
	{




?>

<style>
	#wpg_custom_logo_preview {
		width: 500px !important;
		height: 500px !important;
	}
</style>

<h3><?php _e('Web Payment Gateway Settings', 'woocommerce-gateway-wpgfull'); ?></h3>
<p><?php _e('Web Payment Gateway. The plugin works by opened checkout page, and then sending the details to payment system for verification.', 'woocommerce-gateway-wpgfull'); ?></p>
<input type="hidden" name="" id="wc_api_url" with="500" height="200"  value="<?php echo add_query_arg('wc-api', 'wc_set_picture', home_url('/')); ?>">
<table class="form-table">
	<?php
	 $this->generate_settings_html();
	?>
	<p>
		<strong><?php _e('Callback Url: ') ?></strong><?php echo add_query_arg('wc-api', 'wc_web_payment_gateway', home_url('/')); ?>
	</p>
	<!--  -->
	<tr valign="top" class="">
		<th scope="row" class="titledesc">
			<label for="myprefix_media_manager">Logo </label>
		</th>
		<td class="forminp">
			<fieldset>
				<legend class="screen-reader-text"><span>Preview</span></legend>
				<img id="wpg_custom_logo_prewiev" width="90" height="20" src="<?= $this->icon ?>" alt="<?= $this->title ?>">
				<input type='button' class="button-primary" value="<?php esc_attr_e('Select a image', 'mytextdomain'); ?>" id="myprefix_media_manager" />
				<p class="description">Custom logo payment system.</p>
			</fieldset>
		</td>
	</tr>
	<!--  -->
</table>


<?php
	}




	/**
     * Process the payment and return the result.
     *
     * @param int @order_id
     * @return array
     */
	public function process_payment($order_id)
	{

		$order = new WC_Order($order_id);
		$user = new WP_User($order->get_user_id());
		//get_checkout_payment_url() or WC_Order::get_checkout_order_received_url()

		// return array(
		//     'result' => 'success',
		//     'redirect' => add_query_arg('order', $order->id, add_query_arg('key', $order->get_order_key(), get_permalink(woocommerce_get_page_id('pay'))))
		// );
		return array(
			'result' => 'success',
			'redirect' => $this->get_transaction_url($order),//$this->get_transaction_url($order)
		);
	}





	/**
     * Display information on the Thank You page
     *
     * @param $order
     */
	function receipt_page($order)
	{
		$ord = new WC_Order($order);
		$form = $this->generate_form($order);
		if ($form === false) {
			echo ('</a> <a class="button cancel" href="' . $ord->get_cancel_order_url() . '">' . __('Payment gateway error', 'woocommerce') . '</a>' . "\n");
		} else {
			echo '<p>' . __('Thank you for your order.', 'woocommerce-gateway-wpgfull') . '</p>';
			echo $form;
		}
	}

	public function generate_form($order_id, bool $returnurl = false)
	{
		global $woocommerce;
			
		$order = new WC_Order($order_id);

      $nonce = substr(str_shuffle(MD5(microtime())), 0, 12);
      wc_add_order_item_meta($order_id,'ipn_nonce',$nonce);

		//$action_adr = rtrim($this->url,'/').$this->apimethod['checkout'];
		//fix of not bringing the provide url by adnan.hashmi Nov 18, 2024
		$this->url = $this->get_option('edfa_api_url');
		$action_adr = rtrim($this->url,'/').$this->apimethod['checkout'];
		//end of the fix cod
		
		//$action_adr = $this->url.$this->apimethod['checkout'];
		if ('yes' == $this->debug) {
			$log = new WC_Logger();
			$log->add('wpgLog', 'CheckoutGetUrl: ' .$action_adr);
		}

		if ('yes' == $this->debug) {
			$log = new WC_Logger();
			$log->add('wpgLog', 'firt namer: ' .$order->get_billing_first_name());
			$log->add('wpgLog', 'mb_detect_encoding($order->get_billing_first_name()): ' .mb_detect_encoding($order->get_billing_first_name()));
		}

		$amount = number_format($order->get_total(), 2, '.', '');
		if (in_array(get_woocommerce_currency(), $this->currencies_noexponent)) {
			$amount = number_format($order->get_total(), 0, '.', '');
		}elseif (in_array(get_woocommerce_currency(), $this->currencies_3dotexponent)) {
			$amount = number_format($order->get_total(), 3, '.', '');
		}

		$methods = $this->method; //may error
		//error_log("lg".var_export($methods,true));
		if($methods == null){
			$methods = array();
		}

		$str_to_hash = $order_id . $amount . get_woocommerce_currency() . __('Payment Order # ', 'woocommerce') . $order_id . __(' in the store ', 'woocommerce') . home_url('/') . $this->password;
		$hash = sha1(md5(strtoupper($str_to_hash)));

		
		// Getting the items in the order
		$items = $order->get_items();
		// Iterating through each item in the order
		$items_array = [];

		foreach ($items as $item) {
			$items_array[] = [
				'reference_id' => $item->get_product_id(),
				'sku' => $item->get_product_id(),
				'type' => 'invoice_product',
				'name' => $item->get_name(),
				'quantity' => $item->get_quantity(),
				'amount' => $item->get_total(), // Use get_total() to get the total price for the item
				'currency' => get_woocommerce_currency(),
				// Add more fields as needed
			];
		}

		$product_details_json = json_encode($items_array);
		//callback url
        $args = [
            'wc-api' => 'edfapay_process',
            'orderId'    => base64_encode($order_id),
        ];

        if (isset($_GET['pay_for_order']) &&  $_GET['pay_for_order'] == 'true') {
            $args['pay_for_order'] = 'true';
        }

        $callback_url  = add_query_arg($args, home_url());
		$main_req = array(
			'action' => 'SALE',
			'edfa_merchant_id' => $this->secret,
			'order_id' => "$order_id",
			'order_amount' => $amount,
			'order_currency' => get_woocommerce_currency(),
			'order_description' => __('Payment Order # ', 'woocommerce') . $order_id . __(' in the store ', 'woocommerce') . home_url('/'),

			'req_token' => 'N',
			'product_details' => $product_details_json,
			'payer_first_name' => (mb_detect_encoding($order->get_billing_first_name()) !== 'UTF-8' ? 'First Name' : $order->get_billing_first_name()),
            'payer_last_name' => (mb_detect_encoding($order->get_billing_last_name()) !== 'UTF-8' ? 'Last Name' : $order->get_billing_last_name()),
			'payer_address' => $order->get_billing_address_1() ? $order->get_billing_address_1() : 'NA',
			'payer_country' => $order->get_billing_country() ? $order->get_billing_country() : 'NA',
			'payer_city' => $order->get_billing_city() ? $order->get_billing_city() : 'NA',
			'payer_zip' => $order->get_billing_postcode() ? $order->get_billing_postcode() : 'NA',
			'payer_email' => $order->get_billing_email(),
			'payer_phone' => $order->get_billing_phone() ? $order->get_billing_phone() : 'NA',
			'payer_ip' => '176.44.76.222',
			'auth' => 'N',
			'recurring_init' => 'N',
			'locale' => 'en_US',
			'shipping_first_name' => (mb_detect_encoding($order->get_billing_first_name()) !== 'UTF-8' ? 'First Name' : $order->get_billing_first_name()),
			'shipping_last_name' => (mb_detect_encoding($order->get_billing_last_name()) !== 'UTF-8' ? 'Last Name' : $order->get_billing_last_name()),
			'shipping_address' => $order->get_billing_address_1() ? $order->get_billing_address_1() : 'NA',
			'shipping_city' => $order->get_billing_city() ? $order->get_billing_city() : 'NA',
			'shipping_country_code' => $order->get_billing_country() ? $order->get_billing_country() : 'NA',
			'tax_amount' => '0',
			'tax_currency' => get_woocommerce_currency(),
			'shipping_amount'=> '0',
			'shipping_currency' => get_woocommerce_currency(),
			// 'merchant_success_url' => $callback_url,
			// 'merchant_failure_url' => $callback_url,
			// 'merchant_cancel_url' => $callback_url,
			'term_url_3ds' =>  $callback_url,
			// 'term_url_3ds' => $order->get_checkout_order_received_url(),//$this->get_return_url($order),
			// 'merchant_success_url' => $this->get_return_url($order),
			// 'merchant_failure_url' => $this->get_return_url($order),
			// 'merchant_cancel_url' => $this->get_return_url($order),
			// 'merchant_notification_url' => get_bloginfo('url').'/wc-api/wpgfull_webhook/?nonce='.$nonce.'&order_id='.$order_id,
			'expires_in_minutes' => '30',
			'hash' => $hash,
		);

// print_r($main_req); die;
		if ('yes' == $this->debug) {
			$log = new WC_Logger();
			$log->add('wpgLog', 'adnan.hashmi # 6 Going to post: ' .$action_adr);
		}

		//added code for origin on Nov 30, 2023
		$origin = $_SERVER['HTTP_HOST'];
		//end of edit code by adnan.hashmi

		if ('yes' == $this->debug) {
			$log = new WC_Logger();
			$log->add('wpgLog', '# 7 domain name is: ' .$origin);
		}


		$getter = curl_init($action_adr); //init curl
		curl_setopt($getter, CURLOPT_POST, 1); //post
		curl_setopt($getter, CURLOPT_POSTFIELDS, $main_req);
		curl_setopt($getter, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($getter, CURLOPT_HTTPHEADER, array(
			"Origin: $origin"
		));

		$result = curl_exec($getter);
		$httpcode = curl_getinfo($getter, CURLINFO_HTTP_CODE); 
// 		echo 'check curl request: ';
// print_r($result);
// die();
		if ('yes' == $this->debug) {
			$log = new WC_Logger();
			$log->add('wpgLog', 'CheckoutGet: ' .json_encode($result));
			error_log($httpcode . $result);
		}

		if ($httpcode != 200) {
			if ('yes' == $this->debug) {
				$log = new WC_Logger();
				$log->add('wpgLog', 'CheckoutResponse: ' . $httpcode . ' ' . $result);
				error_log($httpcode . $result);
			}
			return false;
		}
	
		$response = json_decode($result, true);
	
		if ($returnurl === true) {
			return $response['redirect_url'];
		}

		return
			'<a class="button alt" href="' . $response['redirect_url'] . '">' . __('Pay', 'woocommerce') . '</a> <a class="button cancel" href="' . $order->get_cancel_order_url() . '">' . __('Refuse payment & return to cart', 'woocommerce') . '</a>' . "\n";

	}

	public function get_transaction_url($order)
	{
		return $this->generate_form($order->get_id(), true) ? $this->generate_form($order->get_id(), true) : $this->generate_form($order->get_id(), true) ; //$this->get_return_url($order);
	}
}